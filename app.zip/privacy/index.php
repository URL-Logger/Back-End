<!DOCTYPE HTML>
<html>
	<head>
		<title>Privacy Policy</title>
	</head>
	<body style="white-space: pre;"><?php include("policy.html"); ?></body>
</html>