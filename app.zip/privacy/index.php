<!DOCTYPE HTML>
<html>
	<head>
		<title>Privacy Policy</title>
	</head>
	<body>
		<div style="white-space: pre-wrap;"><?php include(dirname(__FILE__)."/policy.html"); ?></div>
	</body>
</html>