<form method="POST" action="login.php">
	<input type="text" name="user" placeholder="User"/><br>
	<input type="text" name="user" placeholder="Pass"/><br>
	<input type="submit" name="submit" value="Login"/><br>
</form>