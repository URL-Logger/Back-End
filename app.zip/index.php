<?php require_once("{$_SERVER['DOCUMENT_ROOT']}/src/header.php");
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title></title>
		<style></style>
		<script></script>
	</head>
	<body>
		<a href="#incomplete">Statistics</a></br>
		<a href="download/">Download</a></br>
		</br>
		<a href="#incomplete">User Accounts</a></br>
		<a href="#incomplete">Settings</a></br>
		</br>
		<a href="#incomplete">My Account</a></br>
		</br>
		<a href="?logout">Logout</a></br>
	</body>
</html>