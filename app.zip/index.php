<?php require_once("{$_SERVER['DOCUMENT_ROOT']}/src/header.php"); ?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Utelem - Home</title>
		<style><?php include_once("./src/styles/layout.php"); ?></style>
	</head>
	<body>
		<?php require_once("{$_SERVER['DOCUMENT_ROOT']}/src/menu.php"); ?>
		</br></br></br>
		<center>Big box links will go here.</center>
	</body>
</html>