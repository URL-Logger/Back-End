<!DOCTYPE HTML>
<html>
	<head>
		<title>Control Panel</title>
	</head>
	<body>
		<input type="button" value="Download" onclick="window.location='download.php'"/>
	</body>
</html>