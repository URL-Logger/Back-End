<?php require_once("{$_SERVER['DOCUMENT_ROOT']}/src/header.php"); ?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Utelem - Home</title>
		<link rel="icon" href="<?=$_CONFIG['FAVICON']?>" type="image/x-icon"/>
		<style><?php include_once("./src/styles/layout.php"); ?>
			body {
				background-image: url('/src/images/landingpage1.jpg');
				background-size: cover;
			}
			
			.boxmenu .button {
				border: 4px solid #000;
				border-radius: 18px;
				box-shadow: 2px 2px 6px <?=$C_BORDER?>;
			}
		</style>
	</head>
	<body>
		<?php require_once("{$_SERVER['DOCUMENT_ROOT']}/src/menu.php"); ?>
		<div class="boxmenu" style="top: 2%;">
			<a class="button" href="users/">User Accounts</a>
			<a class="button" href="manage/">Admin Accounts</a>
			<a class="button" href="download/?browser">Browser Data</a>
			</br>
			<?php
				if(has_privilege('F')) {
					echo "<a class=\"button\" href=\"flush/?browser\">Flush Browser Data</a>";
					echo "<a class=\"button\" href=\"flush/?mobile\">Flush Mobile Data</a>";
				}
				else {
					echo "<div class=\"button disabled\">Flush Browser Data</div>";
					echo "<div class=\"button disabled\">Flush Mobile Data</div>";
				}
			?>
			<a class="button" href="download/?mobile">Mobile Data</a>
		</div>
	</body>
</html>