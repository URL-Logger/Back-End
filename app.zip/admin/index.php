<?php require("header.php"); ?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Control Panel</title>
	</head>
	<body>
	</body>
</html>