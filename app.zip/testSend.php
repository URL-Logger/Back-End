<script>
function sendCurrentUrl(userid, url, title, time, urlid, urlvid, urlrid, trans) {
	var xhr = new XMLHttpRequest();
	xhr.open("POST", 'http://Sample-env.zssmubuwik.us-west-1.elasticbeanstalk.com/post_chrome.php', true);
	
	//Send the proper header information along with the request
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencodedmultipart/form-datatext/plain");
	
	xhr.onreadystatechange = function() {//Call a function when the state changes.
		if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200) {
        // Request finished. Do processing here.
		}
	}
	
	xhr.send(
		'UserID=' + encodeURIComponent(userid) + 
		'&URL=' + encodeURIComponent(url) +
		'&Title=' + encodeURIComponent(title) +
		'&Timestamp=' + encodeURIComponent(time) +
		'&URLID=' + encodeURIComponent(urlid) +
		'&URLVID=' + encodeURIComponent(urlvid) +
		'&URLRID=' + encodeURIComponent(urlrid) +
		'&Transition=' + encodeURIComponent(trans)); 
}

sendCurrentUrl(2, "testUrlInsert", "testTitleInsert", "2017-04-25 13:01", 1, 2, 3, "testTransInsert");
</script>