<?php
// Adds a salt to the password based on the user
function password_salt($user, $pass) {
	return $pass;
}