<center>
	<b>You do not have permission to access this page.</b></br>
	<input type="button" value="Go Back" onclick="window.history.back()"/>
</center>