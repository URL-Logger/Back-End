<?php
$_CONFIG = array(
	# Browser tab icon
	'FAVICON'=> "/src/images/Utelem-graphic-icon-blue-bk 2.png"
);