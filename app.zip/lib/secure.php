<?php
require_once("db.php");

function encrypt_password($user, $pass) {
	return $pass;
}