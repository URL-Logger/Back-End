<?php
require("{$_SERVER['DOCUMENT_ROOT']}/install/clean.php");
require("{$_SERVER['DOCUMENT_ROOT']}/install/install.php");
