<?php
$_USER = -1;
include("{$_SERVER['DOCUMENT_ROOT']}/manage/edit/index.php");
?>