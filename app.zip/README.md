# Back-End
Server and Database programs for our CMPS116 Internship Sponsored by Smart Revenue

Live Version:
http://sample-env.zssmubuwik.us-west-1.elasticbeanstalk.com/

username/password is admin/admin
