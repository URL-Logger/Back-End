<?php require("header.php"); ?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Admin Panel</title>
	</head>
	<body>
	</body>
</html>